# This will be a script that uninstalls Slack from Windows hosts.
# Documentation: https://fleetdm.com/docs/configuration/yaml-files#packages
